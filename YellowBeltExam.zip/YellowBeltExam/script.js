
function cookiesAlert (){
    alert("This site makes use of third-party cookies, by clicking 'I accept' you agree to the terms outlined in our cookie policy.")
}

function changeImage(element){
    element.src = "../YellowBeltExam/assets/succulents-2.jpg";
}

function changeImageback(element){
    element.src = "../YellowBeltExam/assets/succulents-1.jpg";
}

function cartemptyalert(){
    alert("Your cart is empty.")
}

// setTimeout(cookiesAlert, 200);