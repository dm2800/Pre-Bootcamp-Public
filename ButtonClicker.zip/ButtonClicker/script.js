function hide(element){
    element.remove();
}

function logIn(element) {
    element.innerText = "Logout";
}

